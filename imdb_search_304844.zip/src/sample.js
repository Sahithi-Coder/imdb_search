function rum(a,b){
    return a+b;
}

r=rum(6,8)
console.log(r)